<p align="center">
  <a href="https://github.com/VatosV2/Nexus-MultiTool">
    <img src="https://cdn.discordapp.com/attachments/1209895707675205653/1209919950689411092/RmDJt7xVhNFTA6yvy3EWfsTbki45EeI67K93h75F_1.png?ex=6682ec43&is=66819ac3&hm=4809b150641e60e6068a3253a3074aac491f3783021a9e858b7d5bbf4698e101&" alt="Logo" width="80" height="80">
  </a>

  <h3 align="center">[Nexus MultiTool] - https://discord.gg/dS2ZWJrNhZ</h3>

  <p align="center">
    Nexus-MultiTool is a Multitool mostly centered around discord Tokens But also has Other Features.
    <br/>
    <br/>
    <a href="https://discord.gg/dS2ZWJrNhZ">Discord</a>
  </p>
</p>
<h3 align="center";">Please Star To support this project for free! ⭐</h3>
<h3 align="center";">Linux Not supported at the moment! ❌</h3>
<br/>
<h3 align="center";>  https://nexustools.de/ </h3>

## Screenshot
![ss](https://repository-images.githubusercontent.com/765915896/684b1822-40f8-4dc3-972c-f706e56e9243)


## Releases
- 10 Stars for Release ⭐ ✔
- 25 stars for BIG Update. (double of the functions) ⭐ ✔
- 40 Stars V3 ⭐️ ✔
- 65 Stars V4 ⭐️ ✔
- 128 Stars V5 ⭐️ ❌
## Functions
```yaml
- Functions:
  - Token Formater
  - Token Checker
  - Token Sorter
  - Remove Doubles
  - Token Guild Checker
  - Token Guild Leaver
  - Token Spammer
  - Proxy Scraper
  - Proxy Checker
  - Obfusicator 
  - Token Mail Verifier
  - Token Pass Changer
  - Token Onliner
  - Token Status Rotater
  - Get Own Token (Might Trigger Anit-Virus 🔴)
  - Token Login
  - Nitro Gift Checker
  - Token Huminazor
  - Token Watermarker
  - Remove Discord Injection
  - Token Check Payments
  - Token Leave Group Chats
  - Scrape Avatars
  - Token Check Guild Count
  - Token Message everywhere
  - Gen Test Token
  - Token Info
  - Yotube Converter
  - Ip Lookup
  + Id To token
  + Ip grabber
  + Discord Message Logger
  + Serial Checker
  + Serial Changer
  + Theme Changer
- Webhook Tool:
  - Spam webhook
  - Delete webhook
  - Send message
  - Check webhook
- Faker Tool:
  - Fake Token Gen
  - Fake Mail Gen
  - Fake identity 
  - Fake nitro gen
  - Fake ddos
  - Fake cc's
  - Fake Wallet Miner
  - Social Botter
  + Added Fake Paypal Otp
  + Added Fake Account gen
  + Added Fake Fn Checker
  + Added Explination
- Token Nuker:
  - Nuke Token
  - Leave Server
  - Delete Friends
  - Delete Server
  - Mass dm
  - Close Dms
  - Block All Friends
  - Fuck account
- Token Editor:
  - Change Bio
  - Change Name
  - Change Pronouns
  - Change Pfp
- Discord Nuker:
  - Nuke
- Pc Cleaner:
  - Clean Fivem
  - Clean Recent
  - Clean Crashdump
  - Clean Broswer History
  - Clean Broswer Donwloads
  - Clean Desktop
  - Clean Downloads
```
## Latest Change Logs
```yaml
- Changes:
  - Update Gui
  - Added Mapping Dict
  - Changed Printing
  - Updted Token Spammer
  - Added 'Send With Multiple Webhooks' to Webhook Tool
  - Updated Gen-Test-Token
  - Updated Status Rotator
  - Updated Leave Groups
  - Updated Token Checker
- Faker:
  - Added Fake Paypal Otp
  - Added Fake Account gen
  - Added Fake Fn Checker
  - Added Explination
- Added Funcs:
  + Id To token
  + Ip grabber
  + Discord Message Logger
  + Serial Checker
  + Serial Changer
  + Theme Changer
```
## Donate
```py
Ltc:
ltc1qt0eev64v3aq05x7meks443mwugk9269juz0jrt

```
